export class Order_status
{
   ordstatus:string;
}