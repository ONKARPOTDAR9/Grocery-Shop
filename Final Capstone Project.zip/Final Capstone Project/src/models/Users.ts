export class Users
{
id:number=0;	
password:string='';	
username:string='';
}