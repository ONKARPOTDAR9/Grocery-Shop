import { Order_status } from "./Order_status"
import { Users } from "./Users"
export class Orders
{

 id:number;
	
 address:string;
	
 price:number;
	
 OS?:Order_status;
	

UR?:Users;

}