
import { Cart } from "./Cart"
import { Product } from "./Product"
export class Cart_item
{
  id:number
  CR?:Cart
  PR?:Product

}
