import { Orders } from "./Orders"
import { Product } from "./Product"
export class Order_item
{
  id:number;

OR:Orders;


 PR:Product;

price:number;


 qty:number;
}
