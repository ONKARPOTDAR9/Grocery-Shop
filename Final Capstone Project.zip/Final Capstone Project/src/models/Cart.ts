import  { Users } from "./Users"
export class Cart
{
id:number;

UR?:Users
}
